
C++11 was supposedly used

Pthreads were used 

Cygwin64 was used on windows7 machine

Codeblocks was initially used but later failed me

to run and compile: 

//TO RUN PROGRAM + example:
////////////////////////////
// g++ -o proj1 proj1.cpp -lpthread
//
// ./proj1 .03 .10 20
/////////////////////////////
//First parameter represents X% (price increase)
//Second Parameter represents Y% (price decrease)
//Third Parameter represents Z% (buying percentage)

///////////////////////////////////////////////////////////////
//NOTE: IT IS EXTREMELY IMPORTANT TO KEEP X & Y UNDER 15%   //
//THIS IS FURTHER EXPLAINED IN REPORT                        //
///////////////////////////////////////////////////////////////